/*
SNAKE(YILAN) OYUNU
*/

const cvs = document.getElementById("snake"); //Const; sabit demektir.Değişkenin değeri sabittir.Bir kere tanımlanır. 
//GetElementById;etiketin id niteligini kullanılır.
const ctx = cvs.getContext("2d"); //HTML nesneleri içinde olan, yollar, kutular, daireler, yazılar, resimler ve daha fazlasını çizmek için bir çok özelliği ve metodu olan bir gömme'dir.

// Birimi oluşturmak için
const box = 32;

// Görüntüleri yüklemek için

const ground = new Image(); 
ground.src = "img/ground.png";

const foodImg = new Image();
foodImg.src = "img/food.png";

// Ses dosyalarını yüklemek için

//let;Değişkenin değeri sonradan değiştirilebilir.Değiştirilebilir olması için ses dosyalarında let kullanıldı. 
//Bir kez tanımlanabilir.

let dead = new Audio(); 
let eat = new Audio();
let up = new Audio();
let right = new Audio();
let left = new Audio();
let down = new Audio();

dead.src = "audio/dead.mp3"; // src ile komut dosyası içindeki veriye ulaştık.
eat.src = "audio/eat.mp3";
up.src = "audio/up.mp3";
right.src = "audio/right.mp3";
left.src = "audio/left.mp3";
down.src = "audio/down.mp3";

// Yılanı yaratmak için

let snake = [];

snake[0] = {
    x : 9 * box,
    y : 10 * box
};

// yemeği yaratmak için

let food = {
    x : Math.floor(Math.random()*17+1) * box,
    y : Math.floor(Math.random()*15+3) * box
}

// Puan oluşturmak için

let score = 0;

//Yılanı kontrol etmek için
let d;


//addEventListener;istenilen olay gerçekleştiğinde bir metod çalıştırmak için kullanılır.
document.addEventListener("keydown",direction); 

function direction(event){
    let key = event.keyCode; // Burada keycode tablosu yardımıyla sağa sola yukarı aşağı okları tuşlarını kullanmak için.
    if( key == 37 && d != "RIGHT"){ // Sol ok = 37 
        left.play();
        d = "LEFT";
    }else if(key == 38 && d != "DOWN"){ //Aşağı ok = 38
        d = "UP";
        up.play();
    }else if(key == 39 && d != "LEFT"){ // Sağ ok = 39 
        d = "RIGHT";
        right.play();
    }else if(key == 40 && d != "UP"){ //Yukarı ok = 40
        d = "DOWN";
        down.play();
    }
}

// Çarpışma durumunu kontrol etmek için
function collision(head,array){
    for(let i = 0; i < array.length; i++){
        if(head.x == array[i].x && head.y == array[i].y){
            return true;
        }
    }
    return false;
}

// Her şeyin tuvalde,ekranda çizilmesi

function draw(){
    
    ctx.drawImage(ground,0,0);
    for( let i = 0; i < snake.length ; i++){
        ctx.fillStyle = ( i == 0 )? "green" : "white";
        ctx.fillRect(snake[i].x,snake[i].y,box,box);
        
        ctx.strokeStyle = "red";
        ctx.strokeRect(snake[i].x,snake[i].y,box,box);
    }
    
    ctx.drawImage(foodImg, food.x, food.y);
    
    // eski kafa pozisyonu
    let snakeX = snake[0].x;
    let snakeY = snake[0].y;
    
    // hangi yön
    if( d == "LEFT") snakeX -= box;
    if( d == "UP") snakeY -= box;
    if( d == "RIGHT") snakeX += box;
    if( d == "DOWN") snakeY += box;
    
    // Yılan yemek yerse
    if(snakeX == food.x && snakeY == food.y){
        score++;
        eat.play();
        food = {
            x : Math.floor(Math.random()*17+1) * box,
            y : Math.floor(Math.random()*15+3) * box
        }
        // Kuyruğu kaldırmayız
    }else{
        // Kuyruğu kaldır
        snake.pop();
    }
    
    // Yeni baş ekle
    
    let newHead = {
        x : snakeX,
        y : snakeY
    }
    
    // game over
    
    if(snakeX < box || snakeX > 17 * box || snakeY < 3*box || snakeY > 17*box || collision(newHead,snake)){
        clearInterval(game);
        dead.play();
    }
    
    snake.unshift(newHead);
    
    ctx.fillStyle = "white";
    ctx.font = "45px Changa one";
    ctx.fillText(score,2*box,1.6*box);
}

// her 100 ms'de bir çağrı çekme fonksiyonu

let game = setInterval(draw,100);